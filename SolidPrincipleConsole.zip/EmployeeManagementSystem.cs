using EmployeeManagement.IManagement;
namespace EmployeeManagement.Management{
    public class EmployeeManagementSystem{
        private readonly IEmployeeManipulation _employeeManipulation;
        private readonly IEmployeeRead _employeeRead;
        private readonly IEnumerable<IEmployee> _employee;
        private readonly IInputHandler _inputHandler;
        private readonly IAuthenticateUser _authenticateUser;
        private IEmployee _currentUser;
        public EmployeeManagementSystem(IEmployeeManipulation employeeManipulation,IEmployeeRead employeeRead,IEnumerable<IEmployee> employee,IInputHandler inputHandler,IAuthenticateUser authenticateUser){
            _employeeManipulation=employeeManipulation;
            _employeeRead=employeeRead;
            _employee=employee;
            _inputHandler= inputHandler;
            _authenticateUser= authenticateUser;
            if(_employee.Count()==0){
                Console.WriteLine("Registration for Admin Credential");
                IEmployee newEmployee = _inputHandler.GetDataFromConsole(_employee.Count());
                _employeeManipulation.AddEmployee(newEmployee);
            }
        }

        public void AuthenticationSystem(){
            Console.WriteLine("-------------------Welcome---------------------");
            while(true){
                Console.WriteLine("Enter the UserName");
                string name = Console.ReadLine();
                if(_authenticateUser.Login(name)!=null){
                    _currentUser=_employeeRead.GetEmployee(_authenticateUser.Login(name));
                    this.ManagementSystem(_currentUser);
                };
                
            }
        }
        public void ManagementSystem(IEmployee currentUser){
            while(true){
                Console.WriteLine("1. Get Employee");
                Console.WriteLine("2. Get All Employee");
                if(currentUser.Role=="Admin"){
                    Console.WriteLine("3. Add Employee");
                Console.WriteLine("4. Remove Employee");
                }
                Console.WriteLine("5. Logout");
                int options= Convert.ToInt32(Console.ReadLine());
                if(options==1){
                    Console.WriteLine("Enter the Id");
                    int id= Convert.ToInt32(Console.ReadLine());
                    _employeeRead.GetEmployee(id);
                }else if(options==2){
                    _employeeRead.GetAllEmployee();
                }else if(options==3&&currentUser.Role=="Admin"){
                    IEmployee employee=_inputHandler.GetDataFromConsole(_employee.Count());
                    _employeeManipulation.AddEmployee(employee);
                }else if(options==4&&currentUser.Role=="Admin"){
                    Console.WriteLine("Enter the Id");
                    int id= Convert.ToInt32(Console.ReadLine());
                    _employeeManipulation.RemoveEmployee(id);
                }else if(options==5){
                    break;
                }
                else{
                    Console.WriteLine("Incorrect Options");
                }
            }

        }
    }
}