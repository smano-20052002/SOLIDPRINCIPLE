using EmployeeManagement.IManagement;
namespace EmployeeManagement.Management{
    public class InputHandler:IInputHandler{
        public IEmployee GetDataFromConsole(int id){
           Console.WriteLine("Enter Name");
           string name= Console.ReadLine();
           Console.WriteLine("Enter Role");
           string role= Console.ReadLine();
           IEmployee employee= new Employee(++id,name,role);
            return employee;
        }
       
    }
}