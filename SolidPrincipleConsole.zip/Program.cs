﻿// See https://aka.ms/new-console-template for more information

using System;
using EmployeeManagement.Management;
using EmployeeManagement.IManagement;


public class Program
{
    public static void Main(string[] args)
    {
      IList<IEmployee> employeeList= new List<IEmployee>();
      IAuthenticateUser authenticateUser=new AuthenticateUser(employeeList);
      IInputHandler inputHandler=new InputHandler();
      IEmployeeManipulation employeeManipulation= new EmployeeManipulation(employeeList);
      IEmployeeRead employeeRead= new EmployeeRead(employeeList);
      EmployeeManagementSystem employeeManagementSystem= new EmployeeManagementSystem(employeeManipulation,employeeRead,employeeList,inputHandler,authenticateUser);
      employeeManagementSystem.AuthenticationSystem();

    }
}