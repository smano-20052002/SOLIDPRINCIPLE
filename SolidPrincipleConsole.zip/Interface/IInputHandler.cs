namespace EmployeeManagement.IManagement{
    public interface IInputHandler{
        IEmployee GetDataFromConsole(int id);
    }
}