namespace EmployeeManagement.IManagement{
    public interface IEmployeeRead{
        IEmployee GetEmployee(int id);
        void GetAllEmployee();
    }
}