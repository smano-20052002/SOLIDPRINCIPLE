namespace EmployeeManagement.IManagement{
    public interface IAuthenticateUser{
        int Login(string name);
    }
}