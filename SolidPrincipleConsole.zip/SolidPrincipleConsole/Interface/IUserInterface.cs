namespace EmployeeManagement.IManagement{
    public interface IUserInterface{
        IEmployee GetDataFromUser(int id);
        int GetOptionsFromUser();
        int GetEmployeeIdFromUser();
        string GetEmployeeNameFromUser();
        void DisplayOptionForUser(string role);
        void DisplayWelcomeMessage();
    }
}