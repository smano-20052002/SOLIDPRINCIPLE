namespace EmployeeManagement.IManagement{
    public interface IEmployeeManipulation{
        void AddEmployee(IEmployee employee);
        void RemoveEmployee(int id);
    }
}