using EmployeeManagement.IManagement;
namespace EmployeeManagement.Management{
    public class EmployeeManipulation:IEmployeeManipulation{
        private readonly IList<IEmployee> _employee;
        public EmployeeManipulation(IList<IEmployee> employee){
            this._employee=employee;
        }
        public void AddEmployee(IEmployee employee){
            _employee.Add(employee);
            Console.WriteLine($"Employee {employee.Name} is added successfully");
        }
        public void RemoveEmployee(int id){
            IEmployee employee = _employee.FirstOrDefault(emp=>emp.Id==id);
            if(employee!=null){
                _employee.Remove(employee);
                Console.WriteLine($"Employee {employee.Name} is removed successfully");
            }else{
                Console.WriteLine($"Employee {employee.Name} is not exist");
            }
        }
    }
}