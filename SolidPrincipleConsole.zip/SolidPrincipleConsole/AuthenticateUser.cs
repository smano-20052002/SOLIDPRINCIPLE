using EmployeeManagement.IManagement;
namespace EmployeeManagement.Management{
    public class AuthenticateUser:IAuthenticateUser{
        private readonly IEnumerable<IEmployee> _employee;
        public AuthenticateUser(IEnumerable<IEmployee> employee){
            _employee=employee;
        }
        public int Login(string name){
            IEmployee employee=_employee.FirstOrDefault(emp=>emp.Name==name);
            return employee!=null?employee.Id:-1 ;
        }
       
    }
}