using EmployeeManagement.IManagement;
namespace EmployeeManagement.Management{
    public class EmployeeManagementSystem{
        private readonly IEmployeeManipulation _employeeManipulation;
        private readonly IEmployeeRead _employeeRead;
        private readonly IEnumerable<IEmployee> _employee;
        private readonly IUserInterface _userInterface;
        private readonly IAuthenticateUser _authenticateUser;
        private IEmployee _currentUser;
        public EmployeeManagementSystem(IEmployeeManipulation employeeManipulation,IEmployeeRead employeeRead,IEnumerable<IEmployee> employee,IUserInterface userInterface,IAuthenticateUser authenticateUser){
            _employeeManipulation=employeeManipulation;
            _employeeRead=employeeRead;
            _employee=employee;
            _userInterface= userInterface;
            _authenticateUser= authenticateUser;
            if(_employee.Count()==0){
                Console.WriteLine("Registration for Admin Credential");
                IEmployee newEmployee = _userInterface.GetDataFromUser(_employee.Count());
                _employeeManipulation.AddEmployee(newEmployee);
            }
        }

        public void AuthenticationSystem(){
            _userInterface.DisplayWelcomeMessage();
            while(true){
                string name = _userInterface.GetEmployeeNameFromUser();
                int userId=_authenticateUser.Login(name);
                if(userId!=-1){
                    _currentUser=_employeeRead.GetEmployee(userId);
                    this.ManagementSystem(_currentUser);
                }else{
                    Console.WriteLine("Invalid Credentials");
                }
                
            }
        }
        private void ManagementSystem(IEmployee currentUser){
            bool isOperation=true;
            while(isOperation){
                _userInterface.DisplayOptionForUser(currentUser.Role);
                int options= _userInterface.GetOptionsFromUser();
                switch(options){
                    case 1:
                        int id= _userInterface.GetEmployeeIdFromUser();
                        _employeeRead.GetEmployee(id);
                        break;
                    case 2:
                        _employeeRead.GetAllEmployee();
                        break;
                    case 3:
                        IEmployee employee=_userInterface.GetDataFromUser(_employee.Count());
                        _employeeManipulation.AddEmployee(employee);
                        break;
                    case 4:
                        int empid= _userInterface.GetEmployeeIdFromUser();
                        _employeeManipulation.RemoveEmployee(empid);
                        break;
                    case 5:
                        Console.WriteLine("Logged out successfully");
                        isOperation=false;
                        break;

                    default :
                        Console.WriteLine("Incorrect Options");
                        break;
                }                
            }

        }
    }
}