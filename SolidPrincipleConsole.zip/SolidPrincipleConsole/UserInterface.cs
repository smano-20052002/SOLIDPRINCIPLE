using EmployeeManagement.IManagement;
namespace EmployeeManagement.Management{
    public class UserInterface:IUserInterface{
        public IEmployee GetDataFromUser(int id){
           Console.WriteLine("Enter Name");
           string name= Console.ReadLine();
           Console.WriteLine("Enter Role");
           string role= Console.ReadLine();
           IEmployee employee= new Employee(++id,name,role);
            return employee;
        }
        public int GetOptionsFromUser(){
            int options= Convert.ToInt32(Console.ReadLine()); 
            return options;
        }
        public int GetEmployeeIdFromUser(){
            Console.WriteLine("Enter the Id");
            int id= Convert.ToInt32(Console.ReadLine());
            return id;
        }
        public void DisplayOptionForUser(string role){
            Console.WriteLine("1. Get Employee");
            Console.WriteLine("2. Get All Employee");
            if(role=="Admin"){
                Console.WriteLine("3. Add Employee");
                Console.WriteLine("4. Remove Employee");
            }
            Console.WriteLine("5. Logout");
        }
       
        public string GetEmployeeNameFromUser(){
            Console.WriteLine("Enter the UserName");
            string name = Console.ReadLine();
            return name;
        }

        public void DisplayWelcomeMessage(){
            Console.WriteLine("-------------------Welcome---------------------");
        }
       
    }
}