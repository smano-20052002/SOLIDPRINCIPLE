using EmployeeManagement.IManagement;
namespace EmployeeManagement.Management{
    public class EmployeeRead:IEmployeeRead{
        private readonly IList<IEmployee> _employee;
        public EmployeeRead(IList<IEmployee> employee){
            this._employee=employee;
        }
        public IEmployee GetEmployee(int id){
            IEmployee employee=_employee.FirstOrDefault(emp=>emp.Id==id);
            Console.WriteLine("Id: "+ employee.Id);
            Console.WriteLine("Name: "+employee.Name);
            Console.WriteLine("Role: "+employee.Role);
            return employee;
        }
        public void GetAllEmployee(){
           foreach(IEmployee emp in _employee){
            Console.WriteLine("Id: "+ emp.Id);
            Console.WriteLine("Name: "+emp.Name);
            Console.WriteLine("Role: "+emp.Role);
           }
        }
    }
}